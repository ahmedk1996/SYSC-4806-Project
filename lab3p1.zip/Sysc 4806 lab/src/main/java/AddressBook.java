import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.swing.DefaultListModel;
import java.util.*;
@Entity
public class AddressBook {



  //  @OneToMany(cascade = CascadeType.PERSIST)
    public DefaultListModel<JBuddy> jbuddies;
    @Id
    private String id;

    public AddressBook(){
        jbuddies =  new DefaultListModel<JBuddy>();
    }

    public void addBuddy(JBuddy budd){
        jbuddies.addElement(budd);
    }



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public DefaultListModel<JBuddy> getJbuddies() {
        return jbuddies;
    }



    public void setJbuddies(DefaultListModel<JBuddy> jbuddies) {
        this.jbuddies = jbuddies;
    }

    public int getSize(){
        return jbuddies.size();
    }

    public static void main(String[] args){
        AddressBook address = new AddressBook();

        JBuddy student1 = new JBuddy("Ahmed",232232);
        JBuddy student2 = new JBuddy("AK",42232);
        JBuddy student3 = new JBuddy("Ilham",65334);

        address.addBuddy(student1);
        address.addBuddy(student2);
        address.addBuddy(student3);

        address.toString();

    }


}
