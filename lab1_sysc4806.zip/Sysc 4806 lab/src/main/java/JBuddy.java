public class JBuddy {

    private String name;
    private int phoneN;

    public JBuddy(String name, int phoneN){
        this.name = name;
        this.phoneN=phoneN;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhoneN() {
        return phoneN;
    }

    public void setPhoneN(int phoneN) {
        this.phoneN = phoneN;
    }
}
