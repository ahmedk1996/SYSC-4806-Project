import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class AddNewButtonActionListener extends
        ListTableActionListener {
    public void actionPerformed(ActionEvent e) {
        String name = JOptionPane.showInputDialog(null, "What is buddy's name?", "Input Buddy's Name", JOptionPane.QUESTION_MESSAGE);
        int number = Integer.parseInt(JOptionPane.showInputDialog(null, "What is " + name + "'s age?", "Input " + name + "'s age", JOptionPane.QUESTION_MESSAGE));

        JBuddy a = new JBuddy(name, number);
        list.add(a);
        table.revalidate();
    }
}